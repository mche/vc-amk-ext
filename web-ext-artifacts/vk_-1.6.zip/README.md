# ALL GLORY TO GLORIA

`~/vc-amk-ext $ web-ext build --overwrite-dest`

`~/vc-amk-ext $ web-ext sign --api-key=user:10806384:348 --api-secret=....`
